<?php

include('../../../../CONEXAOPHP/conexao.php');

session_start();

$cpf = $_SESSION['cpf'];

$procedure = "select idTB_Gestor from TB_Gestor where Gestor_CPF = '$cpf'";

$sql = mysqli_query($conn, $procedure) or die(mysqli_error($conn));

while ($dados = mysqli_fetch_assoc($sql)) {
    $idTB_Gestor = $dados['idTB_Gestor'];
}
?>



                             




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Avaliações - AUTORATING</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    <link rel="stylesheet" href="../../../PROFILE/assets/bootstrap/css/profile.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="shortcut icon" type="imagex/png" href="../../LOGIN/assets/img/AUTORATING.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"> 
</head>
<body id="body-pd">
    <header class="header" id="header">
        <div style="color: white;" class="header_toggle "> <i class='bx bx-expand-horizontal' id="header-toggle"></i> </div>
        <h3></h3>
        <a href="#" id="btn-sair" class="nav_link"> <i class='bx bx-log-out nav_icon'></i> <span class="nav_name">Sair</span> </a> 
    </header>
    <main>
    <style>
    /* Estiliza o controle de faixa aumentando a largura */
    #faixa {
      width: 100%; /* Aumenta a largura para 80% do elemento pai */
    }
  </style>
        <div class="l-navbar" id="nav-bar"> 
            <nav class="nav">
                <div> <a href="#" class="nav_logo"> <i class='bx bx-layer nav_logo-icon' ></i> <span class="nav_logo-name">Autorating</span> </a>
                <div  class="img m-3"> 
                <img class="rounded-circle mb-3 mt-4" src="../UPLOADS_IMAGENS/<?php echo $tratacaminhoimagem?>" width="160" height="160" id="fotomenu">
                </div>
                <hr>
                    <div class="nav_list mt-4">
                        <a href="../../../MENU/menu.php" class="nav_link"> <i class='bx bx-grid-alt nav_icon'></i> <span class="nav_name">Menu</span> </a> 
                        <a href="../COLEGAS/colegas.php" class="nav_link" > <i class='bx bx-group nav_icon'></i> <span class="nav_name">Meu departamento</span> </a> 
                        <a href="../REALIZADAS/realizadas.php" class="nav_link active"> <i class='bx bx-check nav_icon'></i> <span class="nav_name">Realizadas</span> </a> 
                        <a href="../Dashboard/dashboard.php" class="nav_link "> <i class='bx bx-bar-chart-alt-2 nav_icon'></i> <span class="nav_name">Dashboard</span> </a> 
                        <a href="../profile/profile.php" class="nav_link "> <i class='bx bx-user nav_icon'></i> <span class="nav_name">Dados Pessoais</span> </a>
                    </div>
                </div> 
            </nav>
        </div>

        <br>
          <br>
          <br>

                <blockquote class="blockquote text-center">
            <h3 class="mb-1 p-4" >Criando nova avaliação</h3>
        </blockquote>



    
    <div class="container">
        
        <div class="row">
          <div class="col-sm">
            <table class="table align-middle mb-0 bg-white">
                <thead class="bg-light">
                  <tr>
                    <th>Selecione os colaboradores</th>
                    

                  </tr>
                </thead>
                <tbody>
                <?php 
               

                      $procedure = "select * from TB_Colaborador where TB_Gestor_idTB_Gestor = '$idTB_Gestor';";

                      $contar = "select count(idTB_Colaborador) from TB_Colaborador; ";

                      $sql = mysqli_query($conn, $procedure) or die(mysqli_error($conn));

                      while ($dados = mysqli_fetch_assoc($sql)){
                      $idTB_Colaborador = $dados['idTB_Colaborador'];
                      $nome = $dados['Colaborador_Nome']; 
                      $email = $dados['Colaborador_Email'];
                      $foto = $dados['Colaborador_Foto'];
                      ?>
                  <tr>
                    <td>
                      <div class="d-flex align-items-center">
                        <img
                            src="../../../COLEGAS/CRUD_colegas/<?php echo $foto ?>"
                            alt=""
                            style="width: 45px; height: 45px"
                            class="rounded-circle"
                            />
                        <div class="ms-3">
                          <p class="fw-bold mb-1"><?php echo $nome ?></p>
                          <p class="text-muted mb-0"><?php echo $email ?></p>
                        </div>
                      </div>
                    </td>
                    <td>
                      <input type="checkbox" name="" id="">
                    </td>
                  </tr>
                 
                 
                 <?php } ?>
                </tbody>
              </table>
          </div>
          <div class="col-sm">
            <div class="container">
                <div class="row">
                  <div class="col">
                    <div class="container mt-5">
                        
                        <form>
                          <div class="form-group">
                            <label for="textoInput" class="font-weight-bold">Data de inicio:</label>
                            <input type="date" class="form-control" id="textoInput" placeholder="Digite seu texto">
                          </div>
                          <div class="form-group" >
                            <label for="textoInput" class="font-weight-bold">Data do término:</label>
                            <input type="date" class="form-control" id="textoInput" placeholder="Digite seu texto">
                          </div>
                          <div class="form-group">
                          <label for="textoInput" class="font-weight-bold">Quantidade de questões:</label>
                          <input type="range" id="faixa" min="5" max="15" step="1" value="50">
                          
                         <p>Questões: <span id="valorSelecionado">15</span></p>
                          </div>
                   
                        </form>

                        
                      </div>
                  </div>

              
                  <div class="w-100"></div>
            
                  <div class="col">
            
                    
                    
                    <br>

                    <div class="form-group">
                        <label for="textoTextarea" class="font-weight-bold"s>Descrição da Pesquisa:</label>
                        <textarea class="form-control" id="textoTextarea" rows="5" placeholder="Digite seu texto aqui"></textarea>
                      </div>
                  </div>
                </div>
              </div>
          </div>
          <div class="col-sm">
            <div class="form-outline">
                <table class="table align-middle mb-0 bg-white">
                    <thead class="bg-light">
                      <tr>
                      <th>Selecione as categorias</th>
    
                      </tr>
                    </thead>
                    <tbody>
                    <?php 
               

               $procedure = "select * from tb_categoria";


               $sql = mysqli_query($conn, $procedure) or die(mysqli_error($conn));

               while ($dados = mysqli_fetch_assoc($sql)){
   
               $Categoria_Nome	 = $dados['Categoria_Nome']; 
        
               ?>
                      <tr>
                        <td>
                          <div class="d-flex align-items-center">
                       
                            <div class="ms-3">
                              <p class="fw-bold mb-1"><?php echo $Categoria_Nome ?></p>
                            </div>
                          </div>
                        </td>
                        <td>
                          <input type="checkbox" name="" id="">
                        </td>
                      </tr>   
                      <?php } ?>  
                    </tbody>
                  </table>
          </div>
        </div>
        <div class="container mt-5">
            <form>
         
              <div class="text-center"> <!-- Classe para centralizar conteúdo -->
                <button type="submit" class="btn btn-primary">Enviar</button>
              </div>
            </form>
          </div>
      </div>

                </div>
               
            </div>

    

            

    </main>

    
    <footer class="sticky-footer">
                        <div class="container my-auto">
                            <div class="text-center my-auto copyright"><span>©TECHNOTRIBEMLV2023</span></div>
                        </div>
                    </footer>

    <!-- ... (scripts JavaScript) ... -->

</body>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
  // Captura o elemento de entrada do tipo range
  var faixa = document.getElementById("faixa");
  // Captura o elemento onde exibiremos o valor selecionado
  var valorSelecionado = document.getElementById("valorSelecionado");

  // Adiciona um ouvinte de evento de mudança ao controle de faixa
  faixa.addEventListener("input", function() {
    // Atualiza o valor exibido com o valor selecionado pelo controle de faixa
    valorSelecionado.textContent = faixa.value;
  });
</script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/js/script.min.js"></script>
<script src="assets/js/chart.min.min.js"></script>       
<script src="../../../PROFILE/assets/js/main.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
</html>