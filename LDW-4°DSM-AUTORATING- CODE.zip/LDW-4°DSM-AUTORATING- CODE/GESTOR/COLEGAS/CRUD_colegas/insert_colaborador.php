<?php
include '../../../CONEXAOPHP/conexao.php';

session_start();

$cpf = $_SESSION['cpf'];

$procedure = "select idTB_Gestor from TB_Gestor where Gestor_CPF = '$cpf'";

$sql = mysqli_query($conn, $procedure) or die(mysqli_error($conn));

while ($dados = mysqli_fetch_assoc($sql)) {
    $idTB_Gestor = $dados['idTB_Gestor'];
}

$cpf = $_POST['cpf'];
$nome = $_POST['nome'];
$email = $_POST['email'];
$telefone = $_POST['telefone'];
$nascimento = $_POST['nascimento'];
$admissao = $_POST['admissao'];
$funcao = $_POST['funcao'];
$senha = $_POST['senha'];
$confirmarsenha = $_POST['confirmarsenha'];

$consulta = "SELECT COUNT(*) AS total FROM TB_colaborador WHERE Colaborador_CPF = '$cpf'";
$resultado = mysqli_query($conn, $consulta);

if (!$resultado) {
    die("Erro na consulta: " . mysqli_error($conn));
}


$dados = mysqli_fetch_assoc($resultado);
$total = $dados['total'];


if($total == 0) {


            // Processa o upload da imagem
            $target_dir = "../../../COLABORADOR/UPLOADS_IMAGENS/";
            $target_file = $target_dir . basename($_FILES["imagem"]["name"]);
            $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
            $new_file_name = $cpf . "." . $imageFileType;
            $uploadOk = 1;

            if (isset($_POST["submit"])) {
                $check = getimagesize($_FILES[$new_file_name]);
                if ($check !== false) {
                    echo "O arquivo é uma imagem - " . $check["mime"] . ".";
                    $uploadOk = 1;
                } else {
                    header('location: teladeinsert.php');
                    $_SESSION['status_Problemascomaimagem'] = "";
                    $uploadOk = 0;
                }
            }

            // Verifica se o arquivo já existe
            if (file_exists($target_file)) {
                header('location: teladeinsert.php');
                $_SESSION['status_Problemascomaimagem'] = "";
                $uploadOk = 0;
            }

            // Verifica o tamanho máximo do arquivo (1MB)
            if ($_FILES["imagem"]["size"] > 1000000) {
                header('location: teladeinsert.php');
                $_SESSION['status_Problemascomaimagem'] = "";
                $uploadOk = 0;
            }

            // Permitir apenas formatos de imagem específicos (JPEG, JPG, PNG)
            if ($imageFileType != "jpg" && $imageFileType != "jpeg" && $imageFileType != "png") {
                header('location: teladeinsert.php');
                $_SESSION['status_Problemascomaimagem'] = "";
                $uploadOk = 0;
            }

            // Verifica se $uploadOk é igual a 0 por algum erro
            if ($uploadOk == 0) {
                header('location: teladeinsert.php');
                $_SESSION['status_Problemascomaimagem'] = "";
            } else {
                // Move o arquivo para o diretório de uploads
                if (move_uploaded_file($_FILES["imagem"]["tmp_name"], $target_dir . $new_file_name)) {
                    // Insere as informações no banco de dados
                    $arquivo_nome = $target_dir . $new_file_name;

                    $sql = "INSERT INTO `tb_colaborador` (`TB_Gestor_idTB_Gestor`, `Colaborador_Nome`, `Colaborador_CPF`, `Colaborador_Email`, `Colaborador_Nascimento`, `Colaborador_Telefone`, `Colaborador_Adimissao`, `Colaborador_Senha`, `Colaborador_Status`, `Colaborador_Foto`, `Colaborador_Funcao`) VALUES ('$idTB_Gestor', '$nome', '$cpf', '$email', '$nascimento', '$telefone', '$admissao', '$senha', '1', '$arquivo_nome', '$funcao')";
                    if ($conn->query($sql) === TRUE) {
                        $_SESSION['status_insert'] = "";
                        header("location: ../colegas.php");
                    } else {
                        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
                    }
                } else {
                    header('location: teladeinsert.php');
                    $_SESSION['status_Problemascomaimagem'] = "";
                }
            }

        }else{

            header('location: teladeinsert.php');
            $_SESSION['status_cpfjacadastrado'] = "";

        }
       


// Fecha a conexão com o banco de dados
$conn->close();
?>

