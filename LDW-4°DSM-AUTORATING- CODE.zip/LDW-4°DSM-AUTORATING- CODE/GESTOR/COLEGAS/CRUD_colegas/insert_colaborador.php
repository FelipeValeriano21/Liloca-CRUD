<?php
include '../../../ConexaoPHP/conexao.php';

session_start();

$cpf = $_SESSION['cpf'];

$procedure = "select idTB_Gestor from TB_Gestor where Gestor_CPF = '$cpf'";

$sql = mysqli_query($conn, $procedure) or die(mysqli_error($conn));

while ($dados = mysqli_fetch_assoc($sql)) {
    $idTB_Gestor = $dados['idTB_Gestor'];
}

$cpf = $_POST['cpf'];
$nome = $_POST['nome'];
$email = $_POST['email'];
$telefone = $_POST['telefone'];
$nascimento = $_POST['nascimento'];
$admissao = $_POST['admissao'];
$funcao = $_POST['funcao'];
$senha = $_POST['senha'];
$confirmarsenha = $_POST['confirmarsenha'];

// Consulta SQL para verificar se o CPF já existe
$consulta = "SELECT COUNT(*) AS total FROM TB_colaborador WHERE Colaborador_CPF = '$cpf'";
$resultado = mysqli_query($conn, $consulta);

if (!$resultado) {
    die("Erro na consulta: " . mysqli_error($conn));
}


$dados = mysqli_fetch_assoc($resultado);
$total = $dados['total'];




/////////////////////////////////////

function validarCPF($cpf) {
    // Remove todos os caracteres não numéricos
    $cpf = preg_replace('/[^0-9]/', '', $cpf);

    // Verifica se o CPF possui 11 dígitos
    if (strlen($cpf) != 11) {
        return false;
    }

    // Verifica se todos os dígitos são iguais (CPF inválido)
    if (preg_match('/(\d)\1{10}/', $cpf)) {
        return false;
    }

    // Calcula os dígitos verificadores
    $digito1 = 0;
    $digito2 = 0;

    for ($i = 0; $i < 9; $i++) {
        $digito1 += intval($cpf[$i]) * (10 - $i);
        $digito2 += intval($cpf[$i]) * (11 - $i);
    }

    $digito1 = 11 - ($digito1 % 11);
    if ($digito1 >= 10) {
        $digito1 = 0;
    }

    $digito2 += $digito1 * 2;
    $digito2 = 11 - ($digito2 % 11);
    if ($digito2 >= 10) {
        $digito2 = 0;
    }

    // Verifica se os dígitos verificadores são iguais aos dígitos no CPF original
    if ($cpf[9] == $digito1 && $cpf[10] == $digito2) {
        return true; // CPF válido
    } else {
        return false; // CPF inválido
    }
}


if(validarCPF($cpf) == true){
////////////////////////////////////

if ($cpf != "" && $nome != "" && $email != "" && $telefone != "" && $nascimento != "" && $admissao != "" && $funcao != "" && $senha != "" && $confirmarsenha != "") {

    if ($total == 0) {
 
        if ($senha == $confirmarsenha) {
            // Processa o upload da imagem
            $target_dir = "../../../COLABORADOR/UPLOADS_IMAGENS/";
            $target_file = $target_dir . basename($_FILES["imagem"]["name"]);
            $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
            $new_file_name = $cpf . "." . $imageFileType;
            $uploadOk = 1;

            if (isset($_POST["submit"])) {
                $check = getimagesize($_FILES[$new_file_name]);
                if ($check !== false) {
                    echo "O arquivo é uma imagem - " . $check["mime"] . ".";
                    $uploadOk = 1;
                } else {
                    header('location: teladeinsert.php');
                    $_SESSION['status_Problemascomaimagem'] = "";
                    $uploadOk = 0;
                }
            }

            // Verifica se o arquivo já existe
            if (file_exists($target_file)) {
                header('location: teladeinsert.php');
                $_SESSION['status_Problemascomaimagem'] = "";
                $uploadOk = 0;
            }

            // Verifica o tamanho máximo do arquivo (1MB)
            if ($_FILES["imagem"]["size"] > 1000000) {
                header('location: teladeinsert.php');
                $_SESSION['status_Problemascomaimagem'] = "";
                $uploadOk = 0;
            }

            // Permitir apenas formatos de imagem específicos (JPEG, JPG, PNG)
            if ($imageFileType != "jpg" && $imageFileType != "jpeg" && $imageFileType != "png") {
                header('location: teladeinsert.php');
                $_SESSION['status_Problemascomaimagem'] = "";
                $uploadOk = 0;
            }

            // Verifica se $uploadOk é igual a 0 por algum erro
            if ($uploadOk == 0) {
                header('location: teladeinsert.php');
                $_SESSION['status_Problemascomaimagem'] = "";
            } else {
                // Move o arquivo para o diretório de uploads
                if (move_uploaded_file($_FILES["imagem"]["tmp_name"], $target_dir . $new_file_name)) {
                    // Insere as informações no banco de dados
                    $arquivo_nome = $target_dir . $new_file_name;

                    $sql = "INSERT INTO `tb_colaborador` (`TB_Gestor_idTB_Gestor`, `Colaborador_Nome`, `Colaborador_CPF`, `Colaborador_Email`, `Colaborador_Nascimento`, `Colaborador_Telefone`, `Colaborador_Adimissao`, `Colaborador_Senha`, `Colaborador_Status`, `Colaborador_Foto`, `Colaborador_Funcao`) VALUES ('$idTB_Gestor', '$nome', '$cpf', '$email', '$nascimento', '$telefone', '$admissao', '$senha', '1', '$arquivo_nome', '$funcao')";
                    if ($conn->query($sql) === TRUE) {
                        $_SESSION['status_insert'] = "";
                        header("location: ../colegas.php");
                    } else {
                        header('location: teladeinsert.php');
                        $_SESSION['status_senhasdivergentes'] = "";
                    }
                } else {
                    header('location: teladeinsert.php');
                    $_SESSION['status_Problemascomaimagem'] = "";
                }
            }
        } else {
            header('location: teladeinsert.php');
            $_SESSION['status_senhasdivergentes'] = "";
        }
    }else{

        header('location: teladeinsert.php');
        $_SESSION['status_cpfjacadastrado'] = "";

    }
}else{

    header('location: teladeinsert.php');
    $_SESSION['status_camposembranco'] = "";

}


}else{

    header('location: teladeinsert.php');
    $_SESSION['status_cpf_invalido'] = "";

}


// Fecha a conexão com o banco de dados
$conn->close();
?>

