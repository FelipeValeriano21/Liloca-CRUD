

<?php

include '../../../ConexaoPHP/conexao.php';

if (isset($_GET['idTB_Colaborador'])) {

    $idTB_Colaborador = $_GET['idTB_Colaborador'];

    $sql = "UPDATE TB_Colaborador SET Colaborador_status ='0' WHERE idTB_Colaborador='$idTB_Colaborador'";

    if (mysqli_query($conn, $sql)) {
        session_start();
        header('location: ../colegas.php');
        $_SESSION['Desligadocomsucesso'] = "";
    } else {
        header('location: ../colegas.php');
        $_SESSION['erroaodesligar'] = "";
        
    }

} else {
    header('location: ../colegas.php');
    $_SESSION['erroaodesligar'] = "";  
}

mysqli_close($conn);

?>
