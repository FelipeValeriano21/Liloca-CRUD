

<?php

include '../../../CONEXAOPHP/conexao.php';

if (isset($_GET['idTB_Questoes'])) {

    $idTB_Questoes = $_GET['idTB_Questoes'];

    $sql = "UPDATE tb_questoes SET Questao_Status ='0' WHERE idTB_Questoes='$idTB_Questoes'";

    if (mysqli_query($conn, $sql)) {
        session_start();
        header('location: ../Perguntas.php');
        $_SESSION['Perguntadesligadacomsucesso'] = "";
    } else {
        header('location: ../Perguntas.php');
        $_SESSION['erroaodesligar'] = "";
        
    }

} else {
    header('location: ../Perguntas.php');
        $_SESSION['erroaodesligar'] = "";
}

$conn->close();

?>