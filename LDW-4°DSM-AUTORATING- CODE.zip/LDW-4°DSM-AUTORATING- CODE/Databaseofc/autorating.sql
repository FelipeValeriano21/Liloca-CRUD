-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 05/10/2023 às 22:15
-- Versão do servidor: 8.0.32
-- Versão do PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `autorating`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `empresa_contratante`
--

CREATE TABLE `empresa_contratante` (
  `idEmpresa_Contratante` int NOT NULL,
  `Empresa_Nome` varchar(25) DEFAULT NULL,
  `Empresa_Email` varchar(35) DEFAULT NULL,
  `Empresa_Telefone` varchar(15) DEFAULT NULL,
  `Empresa_Dono` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `empresa_contratante`
--

INSERT INTO `empresa_contratante` (`idEmpresa_Contratante`, `Empresa_Nome`, `Empresa_Email`, `Empresa_Telefone`, `Empresa_Dono`) VALUES
(1, 'Amazon', 'Amazon@gmail.com', '11236985698', 'Jeff Bezos'),
(2, 'Magazine Luiza', 'MagazineLuiza@gmail.com', '11962549632', 'Luiza Helena Trajano');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_categoria`
--

CREATE TABLE `tb_categoria` (
  `idTB_Categoria` int NOT NULL,
  `Categoria_Nome` varchar(35) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `tb_categoria`
--

INSERT INTO `tb_categoria` (`idTB_Categoria`, `Categoria_Nome`) VALUES
(1, 'Lógica de Programação'),
(2, 'Banco de dados'),
(3, 'JAVASCRIPT'),
(4, 'SCRUM');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_colaborador`
--

CREATE TABLE `tb_colaborador` (
  `idTB_Colaborador` int NOT NULL,
  `TB_Gestor_idTB_Gestor` int NOT NULL,
  `Colaborador_Nome` varchar(30) DEFAULT NULL,
  `Colaborador_CPF` varchar(14) DEFAULT NULL,
  `Colaborador_Email` varchar(35) DEFAULT NULL,
  `Colaborador_Nascimento` date DEFAULT NULL,
  `Colaborador_Telefone` varchar(15) DEFAULT NULL,
  `Colaborador_Adimissao` date DEFAULT NULL,
  `Colaborador_Senha` varchar(25) DEFAULT NULL,
  `Colaborador_Status` tinyint(1) DEFAULT NULL,
  `Colaborador_Foto` varchar(255) DEFAULT NULL,
  `Colaborador_Funcao` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `tb_colaborador`
--

INSERT INTO `tb_colaborador` (`idTB_Colaborador`, `TB_Gestor_idTB_Gestor`, `Colaborador_Nome`, `Colaborador_CPF`, `Colaborador_Email`, `Colaborador_Nascimento`, `Colaborador_Telefone`, `Colaborador_Adimissao`, `Colaborador_Senha`, `Colaborador_Status`, `Colaborador_Foto`, `Colaborador_Funcao`) VALUES
(1, 1, 'Fabio Silva', '817.471.100-78', 'Fabio@gmail.com', '1998-02-05', '(11) 2962-9511', '2023-10-05', 'fabio', 1, '../../../COLABORADOR/UPLOADS_IMAGENS/817.471.100-78.png', 'Back-End developer');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_colaborador_associa_tb_questionario`
--

CREATE TABLE `tb_colaborador_associa_tb_questionario` (
  `TB_Colaborador_idTB_Colaborador` int NOT NULL,
  `TB_Questionario_idTB_Questionario` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_departamento`
--

CREATE TABLE `tb_departamento` (
  `idTB_Departamento` int NOT NULL,
  `Departamento_Nome` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `tb_departamento`
--

INSERT INTO `tb_departamento` (`idTB_Departamento`, `Departamento_Nome`) VALUES
(1, 'Recursos Humanos'),
(2, 'Tecnologia da Informação'),
(3, 'Marketing'),
(4, 'Vendas');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_gestor`
--

CREATE TABLE `tb_gestor` (
  `idTB_Gestor` int NOT NULL,
  `TB_Departamento_idTB_Departamento` int NOT NULL,
  `Empresa_Contratante_idEmpresa_Contratante` int NOT NULL,
  `Gestor_Nome` varchar(30) DEFAULT NULL,
  `Gestor_CPF` varchar(14) DEFAULT NULL,
  `Gestor_Email` varchar(35) DEFAULT NULL,
  `Gestor_Nascimento` date DEFAULT NULL,
  `Gestor_Telefone` varchar(15) DEFAULT NULL,
  `Gestor_Adimissao` date DEFAULT NULL,
  `Gestor_Senha` varchar(25) DEFAULT NULL,
  `Gestor_Status` tinyint(1) DEFAULT NULL,
  `Gestor_Foto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `tb_gestor`
--

INSERT INTO `tb_gestor` (`idTB_Gestor`, `TB_Departamento_idTB_Departamento`, `Empresa_Contratante_idEmpresa_Contratante`, `Gestor_Nome`, `Gestor_CPF`, `Gestor_Email`, `Gestor_Nascimento`, `Gestor_Telefone`, `Gestor_Adimissao`, `Gestor_Senha`, `Gestor_Status`, `Gestor_Foto`) VALUES
(1, 2, 1, 'Felipe Reis', '521.569.963-96', 'felipe@fatec.com', '2003-10-09', '11111111', '2023-09-07', '123', 1, '521.569.963-96.png');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_questionario`
--

CREATE TABLE `tb_questionario` (
  `idTB_Questionario` int NOT NULL,
  `Questionario_Descricao` varchar(255) DEFAULT NULL,
  `Questionario_Inicio` datetime DEFAULT NULL,
  `Questionario_Fim` datetime DEFAULT NULL,
  `Questionario_Qta_Perguntas` int DEFAULT NULL,
  `Questionario_Status` tinyint(1) DEFAULT NULL,
  `Questionario_Resultado` int DEFAULT NULL,
  `Questionario_Duracao` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_questoes`
--

CREATE TABLE `tb_questoes` (
  `idTB_Questoes` int NOT NULL,
  `TB_Gestor_idTB_Gestor` int NOT NULL,
  `TB_Tipo_Questao_idTB_Tipo_Questao` int NOT NULL,
  `TB_Categoria_idTB_Categoria` int NOT NULL,
  `Questoes_Pergunta` varchar(255) DEFAULT NULL,
  `Questoes_A` varchar(255) DEFAULT NULL,
  `Questoes_B` varchar(255) DEFAULT NULL,
  `Questoes_C` varchar(255) DEFAULT NULL,
  `Questoes_D` varchar(255) DEFAULT NULL,
  `Questao_Correta` varchar(255) DEFAULT NULL,
  `Questao_Data` date DEFAULT NULL,
  `Questao_Status` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `tb_questoes`
--

INSERT INTO `tb_questoes` (`idTB_Questoes`, `TB_Gestor_idTB_Gestor`, `TB_Tipo_Questao_idTB_Tipo_Questao`, `TB_Categoria_idTB_Categoria`, `Questoes_Pergunta`, `Questoes_A`, `Questoes_B`, `Questoes_C`, `Questoes_D`, `Questao_Correta`, `Questao_Data`, `Questao_Status`) VALUES
(1, 1, 1, 1, 'O que é o IF?', 'condicional', 'Atributo', 'loop', 'Variavel', 'A', '2023-10-05', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_tipo_questao`
--

CREATE TABLE `tb_tipo_questao` (
  `idTB_Tipo_Questao` int NOT NULL,
  `Tipo_Nome` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `tb_tipo_questao`
--

INSERT INTO `tb_tipo_questao` (`idTB_Tipo_Questao`, `Tipo_Nome`) VALUES
(1, 'Tecnica'),
(2, 'Comportamental');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `empresa_contratante`
--
ALTER TABLE `empresa_contratante`
  ADD PRIMARY KEY (`idEmpresa_Contratante`);

--
-- Índices de tabela `tb_categoria`
--
ALTER TABLE `tb_categoria`
  ADD PRIMARY KEY (`idTB_Categoria`);

--
-- Índices de tabela `tb_colaborador`
--
ALTER TABLE `tb_colaborador`
  ADD PRIMARY KEY (`idTB_Colaborador`),
  ADD KEY `TB_Colaborador_FKIndex1` (`TB_Gestor_idTB_Gestor`),
  ADD KEY `IFK_Rel_22` (`TB_Gestor_idTB_Gestor`);

--
-- Índices de tabela `tb_colaborador_associa_tb_questionario`
--
ALTER TABLE `tb_colaborador_associa_tb_questionario`
  ADD PRIMARY KEY (`TB_Colaborador_idTB_Colaborador`,`TB_Questionario_idTB_Questionario`),
  ADD KEY `TB_Colaborador_has_TB_Questionario_FKIndex1` (`TB_Colaborador_idTB_Colaborador`),
  ADD KEY `TB_Colaborador_has_TB_Questionario_FKIndex2` (`TB_Questionario_idTB_Questionario`),
  ADD KEY `IFK_Rel_33` (`TB_Colaborador_idTB_Colaborador`),
  ADD KEY `IFK_Rel_34` (`TB_Questionario_idTB_Questionario`);

--
-- Índices de tabela `tb_departamento`
--
ALTER TABLE `tb_departamento`
  ADD PRIMARY KEY (`idTB_Departamento`);

--
-- Índices de tabela `tb_gestor`
--
ALTER TABLE `tb_gestor`
  ADD PRIMARY KEY (`idTB_Gestor`),
  ADD KEY `TB_Gestor_FKIndex1` (`Empresa_Contratante_idEmpresa_Contratante`),
  ADD KEY `TB_Gestor_FKIndex2` (`TB_Departamento_idTB_Departamento`),
  ADD KEY `IFK_Rel_20` (`Empresa_Contratante_idEmpresa_Contratante`),
  ADD KEY `IFK_Rel_21` (`TB_Departamento_idTB_Departamento`);

--
-- Índices de tabela `tb_questionario`
--
ALTER TABLE `tb_questionario`
  ADD PRIMARY KEY (`idTB_Questionario`);

--
-- Índices de tabela `tb_questoes`
--
ALTER TABLE `tb_questoes`
  ADD PRIMARY KEY (`idTB_Questoes`),
  ADD KEY `TB_Questoes_FKIndex1` (`TB_Categoria_idTB_Categoria`),
  ADD KEY `TB_Questoes_FKIndex2` (`TB_Tipo_Questao_idTB_Tipo_Questao`),
  ADD KEY `TB_Questoes_FKIndex3` (`TB_Gestor_idTB_Gestor`),
  ADD KEY `IFK_Rel_23` (`TB_Categoria_idTB_Categoria`),
  ADD KEY `IFK_Rel_24` (`TB_Tipo_Questao_idTB_Tipo_Questao`),
  ADD KEY `IFK_Rel_25` (`TB_Gestor_idTB_Gestor`);

--
-- Índices de tabela `tb_tipo_questao`
--
ALTER TABLE `tb_tipo_questao`
  ADD PRIMARY KEY (`idTB_Tipo_Questao`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `empresa_contratante`
--
ALTER TABLE `empresa_contratante`
  MODIFY `idEmpresa_Contratante` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `tb_categoria`
--
ALTER TABLE `tb_categoria`
  MODIFY `idTB_Categoria` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `tb_colaborador`
--
ALTER TABLE `tb_colaborador`
  MODIFY `idTB_Colaborador` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `tb_departamento`
--
ALTER TABLE `tb_departamento`
  MODIFY `idTB_Departamento` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `tb_gestor`
--
ALTER TABLE `tb_gestor`
  MODIFY `idTB_Gestor` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `tb_questionario`
--
ALTER TABLE `tb_questionario`
  MODIFY `idTB_Questionario` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `tb_questoes`
--
ALTER TABLE `tb_questoes`
  MODIFY `idTB_Questoes` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `tb_tipo_questao`
--
ALTER TABLE `tb_tipo_questao`
  MODIFY `idTB_Tipo_Questao` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `tb_colaborador`
--
ALTER TABLE `tb_colaborador`
  ADD CONSTRAINT `tb_colaborador_ibfk_1` FOREIGN KEY (`TB_Gestor_idTB_Gestor`) REFERENCES `tb_gestor` (`idTB_Gestor`);

--
-- Restrições para tabelas `tb_colaborador_associa_tb_questionario`
--
ALTER TABLE `tb_colaborador_associa_tb_questionario`
  ADD CONSTRAINT `tb_colaborador_associa_tb_questionario_ibfk_1` FOREIGN KEY (`TB_Colaborador_idTB_Colaborador`) REFERENCES `tb_colaborador` (`idTB_Colaborador`),
  ADD CONSTRAINT `tb_colaborador_associa_tb_questionario_ibfk_2` FOREIGN KEY (`TB_Questionario_idTB_Questionario`) REFERENCES `tb_questionario` (`idTB_Questionario`);

--
-- Restrições para tabelas `tb_gestor`
--
ALTER TABLE `tb_gestor`
  ADD CONSTRAINT `tb_gestor_ibfk_1` FOREIGN KEY (`Empresa_Contratante_idEmpresa_Contratante`) REFERENCES `empresa_contratante` (`idEmpresa_Contratante`),
  ADD CONSTRAINT `tb_gestor_ibfk_2` FOREIGN KEY (`TB_Departamento_idTB_Departamento`) REFERENCES `tb_departamento` (`idTB_Departamento`);

--
-- Restrições para tabelas `tb_questoes`
--
ALTER TABLE `tb_questoes`
  ADD CONSTRAINT `tb_questoes_ibfk_1` FOREIGN KEY (`TB_Categoria_idTB_Categoria`) REFERENCES `tb_categoria` (`idTB_Categoria`),
  ADD CONSTRAINT `tb_questoes_ibfk_2` FOREIGN KEY (`TB_Tipo_Questao_idTB_Tipo_Questao`) REFERENCES `tb_tipo_questao` (`idTB_Tipo_Questao`),
  ADD CONSTRAINT `tb_questoes_ibfk_3` FOREIGN KEY (`TB_Gestor_idTB_Gestor`) REFERENCES `tb_gestor` (`idTB_Gestor`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
