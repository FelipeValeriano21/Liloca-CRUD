



CREATE TABLE TB_Departamento (
  idTB_Departamento INTEGER   NOT NULL ,
  Departamento_Nome VARCHAR(25)      ,
PRIMARY KEY(idTB_Departamento));




CREATE TABLE TB_Tipo_Questao (
  idTB_Tipo_Questao INTEGER   NOT NULL ,
  Tipo_Nome VARCHAR(20)    ,
  Tipo_Descricao VARCHAR(255)      ,
PRIMARY KEY(idTB_Tipo_Questao));




CREATE TABLE TB_Categoria (
  idTB_Categoria INTEGER   NOT NULL ,
  Categoria_Nome VARCHAR(35)      ,
PRIMARY KEY(idTB_Categoria));




CREATE TABLE Empresa_Contratante (
  idEmpresa_Contratante INTEGER   NOT NULL ,
  Empresa_Nome VARCHAR(25)    ,
  Empresa_Email VARCHAR(35)    ,
  Empresa_Telefone VARCHAR(15)    ,
  Empresa_Dono VARCHAR(25)      ,
PRIMARY KEY(idEmpresa_Contratante));




CREATE TABLE TB_Gestor (
  idTB_Gestor INTEGER   NOT NULL ,
  TB_Departamento_idTB_Departamento INTEGER   NOT NULL ,
  Empresa_Contratante_idEmpresa_Contratante INTEGER   NOT NULL ,
  Gestor_Nome VARCHAR(30)    ,
  Gestor_CPF VARCHAR(14)    ,
  Gestor_Email VARCHAR(35)    ,
  Gestor_Nascimento DATE    ,
  Gestor_Telefone VARCHAR(15)    ,
  Gestor_Adimissao DATE    ,
  Gestor_Senha VARCHAR(25)    ,
  Gestor_Status BOOL    ,
  Gestor_Foto VARCHAR(255)      ,
PRIMARY KEY(idTB_Gestor)    ,
  FOREIGN KEY(Empresa_Contratante_idEmpresa_Contratante)
    REFERENCES Empresa_Contratante(idEmpresa_Contratante),
  FOREIGN KEY(TB_Departamento_idTB_Departamento)
    REFERENCES TB_Departamento(idTB_Departamento));


CREATE INDEX TB_Gestor_FKIndex2 ON TB_Gestor (Empresa_Contratante_idEmpresa_Contratante);
CREATE INDEX TB_Gestor_FKIndex2 ON TB_Gestor (TB_Departamento_idTB_Departamento);


CREATE INDEX IFK_Rel_09 ON TB_Gestor (Empresa_Contratante_idEmpresa_Contratante);
CREATE INDEX IFK_Rel_10 ON TB_Gestor (TB_Departamento_idTB_Departamento);


CREATE TABLE TB_Questoes (
  idTB_Questoes INTEGER   NOT NULL ,
  TB_Gestor_idTB_Gestor INTEGER   NOT NULL ,
  TB_Tipo_Questao_idTB_Tipo_Questao INTEGER   NOT NULL ,
  TB_Categoria_idTB_Categoria INTEGER   NOT NULL ,
  Questoes_Pergunta VARCHAR(255)    ,
  Questoes_A VARCHAR(255)    ,
  Questoes_B VARCHAR(255)    ,
  Questoes_C VARCHAR(255)    ,
  Questoes_D VARCHAR(255)    ,
  Questao_Correta VARCHAR(255)    ,
  Questao_Data DATE    ,
  Questao_Status BOOL      ,
PRIMARY KEY(idTB_Questoes)      ,
  FOREIGN KEY(TB_Categoria_idTB_Categoria)
    REFERENCES TB_Categoria(idTB_Categoria),
  FOREIGN KEY(TB_Tipo_Questao_idTB_Tipo_Questao)
    REFERENCES TB_Tipo_Questao(idTB_Tipo_Questao),
  FOREIGN KEY(TB_Gestor_idTB_Gestor)
    REFERENCES TB_Gestor(idTB_Gestor));


CREATE INDEX TB_Questoes_FKIndex1 ON TB_Questoes (TB_Categoria_idTB_Categoria);
CREATE INDEX TB_Questoes_FKIndex2 ON TB_Questoes (TB_Tipo_Questao_idTB_Tipo_Questao);
CREATE INDEX TB_Questoes_FKIndex3 ON TB_Questoes (TB_Gestor_idTB_Gestor);


CREATE INDEX IFK_Rel_04 ON TB_Questoes (TB_Categoria_idTB_Categoria);
CREATE INDEX IFK_Rel_05 ON TB_Questoes (TB_Tipo_Questao_idTB_Tipo_Questao);
CREATE INDEX IFK_Rel_09 ON TB_Questoes (TB_Gestor_idTB_Gestor);


CREATE TABLE TB_Questionario (
  idTB_Questionario INTEGER   NOT NULL ,
  TB_Gestor_idTB_Gestor INTEGER   NOT NULL ,
  Questionario_Descricao VARCHAR(255)    ,
  Questionario_Inicio DATETIME    ,
  Questionario_Fim DATETIME    ,
  Questionario_Qta_Perguntas INTEGER    ,
  Questionario_Status BOOL    ,
  Questionario_Resultado  INTEGER    ,
  Questionario_Duracao TIME      ,
  FOREIGN KEY(TB_Gestor_idTB_Gestor)
    REFERENCES TB_Gestor(idTB_Gestor));


CREATE INDEX TB_Questionario_FKIndex2 ON TB_Questionario (TB_Gestor_idTB_Gestor);


CREATE INDEX IFK_Rel_09 ON TB_Questionario (TB_Gestor_idTB_Gestor);


CREATE TABLE TB_Colaborador (
  idTB_Colaborador INTEGER   NOT NULL ,
  TB_Gestor_idTB_Gestor INTEGER   NOT NULL ,
  Colaborador_Nome VARCHAR(30)    ,
  Colaborador_CPF VARCHAR(11)    ,
  Colaborador_Email VARCHAR(35)    ,
  Colaborador_Nascimento DATE    ,
  Colaborador_Telefone VARCHAR(15)    ,
  Colaborador_Adimissao DATE    ,
  Colaborador_Senha VARCHAR(25)    ,
  Colaborador_Status BOOL    ,
  Colaborador_Foto VARCHAR(255)    ,
  Colaboorador_Funcao VARCHAR(20)      ,
PRIMARY KEY(idTB_Colaborador)  ,
  FOREIGN KEY(TB_Gestor_idTB_Gestor)
    REFERENCES TB_Gestor(idTB_Gestor));


CREATE INDEX TB_Colaborador_FKIndex1 ON TB_Colaborador (TB_Gestor_idTB_Gestor);


CREATE INDEX IFK_Rel_01 ON TB_Colaborador (TB_Gestor_idTB_Gestor);


CREATE TABLE TB_Colaborador_has_TB_Questionario (
  TB_Colaborador_idTB_Colaborador INTEGER   NOT NULL   ,
PRIMARY KEY(TB_Colaborador_idTB_Colaborador)  ,
  FOREIGN KEY(TB_Colaborador_idTB_Colaborador)
    REFERENCES TB_Colaborador(idTB_Colaborador),
  FOREIGN KEY()
    REFERENCES TB_Questionario());


CREATE INDEX TB_Colaborador_has_TB_Questionario_FKIndex1 ON TB_Colaborador_has_TB_Questionario (TB_Colaborador_idTB_Colaborador);


CREATE INDEX IFK_Rel_10 ON TB_Colaborador_has_TB_Questionario (TB_Colaborador_idTB_Colaborador);
CREATE INDEX IFK_Rel_11 ON TB_Colaborador_has_TB_Questionario (TB_Questionario_idTB_Questionario);

