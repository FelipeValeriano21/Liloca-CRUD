
create database autorating; 
use autorating;



CREATE TABLE TB_Departamento (
  idTB_Departamento INTEGER   NOT NULL AUTO_INCREMENT ,
  Departamento_Nome VARCHAR(25)      ,
PRIMARY KEY(idTB_Departamento));




CREATE TABLE TB_Tipo_Questao (
  idTB_Tipo_Questao INTEGER   NOT NULL AUTO_INCREMENT ,
  Tipo_Nome VARCHAR(20)    ,
  Tipo_Descricao VARCHAR(255)      ,
PRIMARY KEY(idTB_Tipo_Questao));




CREATE TABLE TB_Categoria (
  idTB_Categoria INTEGER   NOT NULL AUTO_INCREMENT ,
  Categoria_Nome VARCHAR(35)      ,
PRIMARY KEY(idTB_Categoria));




CREATE TABLE Empresa_Contratante (
  idEmpresa_Contratante INTEGER   NOT NULL AUTO_INCREMENT ,
  Empresa_Nome VARCHAR(25)    ,
  Empresa_Email VARCHAR(35)    ,
  Empresa_Telefone VARCHAR(15)    ,
  Empresa_Dono VARCHAR(25)      ,
PRIMARY KEY(idEmpresa_Contratante));




CREATE TABLE TB_Gestor (
  idTB_Gestor INTEGER   NOT NULL AUTO_INCREMENT ,
  TB_Departamento_idTB_Departamento INTEGER   NOT NULL ,
  Empresa_Contratante_idEmpresa_Contratante INTEGER   NOT NULL ,
  Gestor_Nome VARCHAR(30)    ,
  Gestor_CPF VARCHAR(11)    ,
  Gestor_Email VARCHAR(35)    ,
  Gestor_Nascimento DATE    ,
  Gestor_Telefone VARCHAR(15)    ,
  Gestor_Adimissao DATE    ,
  Gestor_Senha VARCHAR(25)    ,
  Gestor_Status BOOLEAN    ,
  Gestor_Foto VARCHAR(255)      ,
PRIMARY KEY(idTB_Gestor)    ,
  FOREIGN KEY(Empresa_Contratante_idEmpresa_Contratante)
    REFERENCES Empresa_Contratante(idEmpresa_Contratante),
  FOREIGN KEY(TB_Departamento_idTB_Departamento)
    REFERENCES TB_Departamento(idTB_Departamento));


CREATE INDEX TB_Gestor_FKIndex1 ON TB_Gestor (Empresa_Contratante_idEmpresa_Contratante);
CREATE INDEX TB_Gestor_FKIndex2 ON TB_Gestor (TB_Departamento_idTB_Departamento);


CREATE INDEX IFK_Rel_20 ON TB_Gestor (Empresa_Contratante_idEmpresa_Contratante);
CREATE INDEX IFK_Rel_21 ON TB_Gestor (TB_Departamento_idTB_Departamento);


CREATE TABLE TB_Questoes (
  idTB_Questoes INTEGER   NOT NULL AUTO_INCREMENT,
  TB_Gestor_idTB_Gestor INTEGER   NOT NULL ,
  TB_Tipo_Questao_idTB_Tipo_Questao INTEGER   NOT NULL ,
  TB_Categoria_idTB_Categoria INTEGER   NOT NULL ,
  Questoes_Pergunta VARCHAR(255)    ,
  Questoes_A VARCHAR(255)    ,
  Questoes_B VARCHAR(255)    ,
  Questoes_C VARCHAR(255)    ,
  Questoes_D VARCHAR(255)    ,
  Questao_Correta VARCHAR(255)    ,
  Questao_Data DATE    ,
  Questao_Status BOOLEAN      ,
PRIMARY KEY(idTB_Questoes)      ,
  FOREIGN KEY(TB_Categoria_idTB_Categoria)
    REFERENCES TB_Categoria(idTB_Categoria),
  FOREIGN KEY(TB_Tipo_Questao_idTB_Tipo_Questao)
    REFERENCES TB_Tipo_Questao(idTB_Tipo_Questao),
  FOREIGN KEY(TB_Gestor_idTB_Gestor)
    REFERENCES TB_Gestor(idTB_Gestor));


CREATE INDEX TB_Questoes_FKIndex1 ON TB_Questoes (TB_Categoria_idTB_Categoria);
CREATE INDEX TB_Questoes_FKIndex2 ON TB_Questoes (TB_Tipo_Questao_idTB_Tipo_Questao);
CREATE INDEX TB_Questoes_FKIndex3 ON TB_Questoes (TB_Gestor_idTB_Gestor);


CREATE INDEX IFK_Rel_23 ON TB_Questoes (TB_Categoria_idTB_Categoria);
CREATE INDEX IFK_Rel_24 ON TB_Questoes (TB_Tipo_Questao_idTB_Tipo_Questao);
CREATE INDEX IFK_Rel_25 ON TB_Questoes (TB_Gestor_idTB_Gestor);


CREATE TABLE TB_Questionario (
  idTB_Questionario INTEGER   NOT NULL AUTO_INCREMENT,
  TB_Gestor_idTB_Gestor INTEGER   NOT NULL ,
  Questionario_Descricao VARCHAR(255)    ,
  Questionario_Inicio DATETIME    ,
  Questionario_Fim DATETIME    ,
  Questionario_Qta_Perguntas INTEGER    ,
  Questionario_Status BOOLEAN      ,
PRIMARY KEY(idTB_Questionario)  ,
  FOREIGN KEY(TB_Gestor_idTB_Gestor)
    REFERENCES TB_Gestor(idTB_Gestor));


CREATE INDEX TB_Questionario_FKIndex1 ON TB_Questionario (TB_Gestor_idTB_Gestor);


CREATE INDEX IFK_Rel_09 ON TB_Questionario (TB_Gestor_idTB_Gestor);


CREATE TABLE TB_Colaborador (
  idTB_Colaborador INTEGER   NOT NULL AUTO_INCREMENT,
  TB_Gestor_idTB_Gestor INTEGER   NOT NULL ,
  Colaborador_Nome VARCHAR(30)    ,
  Colaborador_CPF VARCHAR(11)    ,
  Colaborador_Email VARCHAR(35)    ,
  Colaborador_Nascimento DATE    ,
  Colaborador_Telefone VARCHAR(15)    ,
  Colaborador_Adimissao DATE    ,
  Colaborador_Senha VARCHAR(25)    ,
  Colaborador_Status BOOLEAN    ,
  Colaborador_Foto VARCHAR(255)    ,
  Colaborador_Funcao VARCHAR(20)      ,
PRIMARY KEY(idTB_Colaborador)  ,
  FOREIGN KEY(TB_Gestor_idTB_Gestor)
    REFERENCES TB_Gestor(idTB_Gestor));


CREATE INDEX TB_Colaborador_FKIndex1 ON TB_Colaborador (TB_Gestor_idTB_Gestor);


CREATE INDEX IFK_Rel_22 ON TB_Colaborador (TB_Gestor_idTB_Gestor);


CREATE TABLE TB_Questionario_has_TB_Categoria (
  TB_Questionario_idTB_Questionario INTEGER   NOT NULL ,
  TB_Categoria_idTB_Categoria INTEGER   NOT NULL   ,
PRIMARY KEY(TB_Questionario_idTB_Questionario, TB_Categoria_idTB_Categoria)    ,
  FOREIGN KEY(TB_Questionario_idTB_Questionario)
    REFERENCES TB_Questionario(idTB_Questionario),
  FOREIGN KEY(TB_Categoria_idTB_Categoria)
    REFERENCES TB_Categoria(idTB_Categoria));


CREATE INDEX TB_Questionario_has_TB_Categoria_FKIndex1 ON TB_Questionario_has_TB_Categoria (TB_Questionario_idTB_Questionario);
CREATE INDEX TB_Questionario_has_TB_Categoria_FKIndex2 ON TB_Questionario_has_TB_Categoria (TB_Categoria_idTB_Categoria);


CREATE INDEX IFK_Rel_10 ON TB_Questionario_has_TB_Categoria (TB_Questionario_idTB_Questionario);
CREATE INDEX IFK_Rel_11 ON TB_Questionario_has_TB_Categoria (TB_Categoria_idTB_Categoria);


CREATE TABLE TB_Colaborador_associa_TB_Questionario (
  TB_Colaborador_idTB_Colaborador INTEGER   NOT NULL ,
  TB_Questionario_idTB_Questionario INTEGER   NOT NULL ,
  Respostas_Certas INTEGER    ,
  Respostas_Erradas INTEGER    ,
  Resultado_Final FLOAT      ,
PRIMARY KEY(TB_Colaborador_idTB_Colaborador, TB_Questionario_idTB_Questionario)    ,
  FOREIGN KEY(TB_Colaborador_idTB_Colaborador)
    REFERENCES TB_Colaborador(idTB_Colaborador),
  FOREIGN KEY(TB_Questionario_idTB_Questionario)
    REFERENCES TB_Questionario(idTB_Questionario));


CREATE INDEX TB_Colaborador_has_TB_Questionario_FKIndex1 ON TB_Colaborador_associa_TB_Questionario (TB_Colaborador_idTB_Colaborador);
CREATE INDEX TB_Colaborador_has_TB_Questionario_FKIndex2 ON TB_Colaborador_associa_TB_Questionario (TB_Questionario_idTB_Questionario);


CREATE INDEX IFK_Rel_33 ON TB_Colaborador_associa_TB_Questionario (TB_Colaborador_idTB_Colaborador);
CREATE INDEX IFK_Rel_34 ON TB_Colaborador_associa_TB_Questionario (TB_Questionario_idTB_Questionario);



