-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 11/10/2023 às 15:35
-- Versão do servidor: 8.0.32
-- Versão do PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `autorating`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `empresa_contratante`
--

CREATE TABLE `empresa_contratante` (
  `idEmpresa_Contratante` int NOT NULL,
  `Empresa_Nome` varchar(25) DEFAULT NULL,
  `Empresa_Email` varchar(35) DEFAULT NULL,
  `Empresa_Telefone` varchar(15) DEFAULT NULL,
  `Empresa_Dono` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `empresa_contratante`
--

INSERT INTO `empresa_contratante` (`idEmpresa_Contratante`, `Empresa_Nome`, `Empresa_Email`, `Empresa_Telefone`, `Empresa_Dono`) VALUES
(1, 'Amazon Brasil', 'Amazon@gmail.com', '11236985698', 'Jeff Bezos'),
(2, 'Americanas', 'Americanas@gmail.com', '11962549632', 'Jorge Paulo Lemann');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_categoria`
--

CREATE TABLE `tb_categoria` (
  `idTB_Categoria` int NOT NULL,
  `Categoria_Nome` varchar(35) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `tb_categoria`
--

INSERT INTO `tb_categoria` (`idTB_Categoria`, `Categoria_Nome`) VALUES
(1, 'Banco de dados'),
(2, 'SCRUM'),
(3, 'JAVASCRIPT'),
(4, 'Estatistica Aplicada'),
(5, 'PHP'),
(6, 'Algebra linear'),
(7, 'Front-end');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_colaborador`
--

CREATE TABLE `tb_colaborador` (
  `idTB_Colaborador` int NOT NULL,
  `TB_Gestor_idTB_Gestor` int NOT NULL,
  `Colaborador_Nome` varchar(30) DEFAULT NULL,
  `Colaborador_CPF` varchar(14) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Colaborador_Email` varchar(35) DEFAULT NULL,
  `Colaborador_Nascimento` date DEFAULT NULL,
  `Colaborador_Telefone` varchar(15) DEFAULT NULL,
  `Colaborador_Adimissao` date DEFAULT NULL,
  `Colaborador_Senha` varchar(25) DEFAULT NULL,
  `Colaborador_Status` tinyint(1) DEFAULT NULL,
  `Colaborador_Foto` varchar(255) DEFAULT NULL,
  `Colaborador_Funcao` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `tb_colaborador`
--

INSERT INTO `tb_colaborador` (`idTB_Colaborador`, `TB_Gestor_idTB_Gestor`, `Colaborador_Nome`, `Colaborador_CPF`, `Colaborador_Email`, `Colaborador_Nascimento`, `Colaborador_Telefone`, `Colaborador_Adimissao`, `Colaborador_Senha`, `Colaborador_Status`, `Colaborador_Foto`, `Colaborador_Funcao`) VALUES
(1, 1, 'Felipe Valeriano dos Reis', '525.412.968-94', 'lucasvalerianodosreis@gmail.com', '2023-10-18', '11962849591', '2023-10-11', 'felipe', 1, '../../../COLABORADOR/UPLOADS_IMAGENS/525.412.968-94.jpg', 'back-end');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_colaborador_associa_tb_questionario`
--

CREATE TABLE `tb_colaborador_associa_tb_questionario` (
  `TB_Colaborador_idTB_Colaborador` int NOT NULL,
  `TB_Questionario_idTB_Questionario` int NOT NULL,
  `Respostas_Certas` int DEFAULT NULL,
  `Respostas_Erradas` int DEFAULT NULL,
  `Resultado_Final` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `tb_colaborador_associa_tb_questionario`
--

INSERT INTO `tb_colaborador_associa_tb_questionario` (`TB_Colaborador_idTB_Colaborador`, `TB_Questionario_idTB_Questionario`, `Respostas_Certas`, `Respostas_Erradas`, `Resultado_Final`) VALUES
(1, 7, 5, 5, 5),
(1, 9, NULL, NULL, NULL),
(1, 11, NULL, NULL, NULL),
(1, 12, NULL, NULL, NULL),
(1, 13, NULL, NULL, NULL),
(1, 14, NULL, NULL, NULL),
(1, 15, NULL, NULL, NULL),
(1, 16, NULL, NULL, NULL),
(1, 17, NULL, NULL, NULL),
(1, 19, NULL, NULL, NULL),
(1, 20, NULL, NULL, NULL),
(1, 21, NULL, NULL, NULL),
(1, 22, NULL, NULL, NULL),
(1, 23, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_departamento`
--

CREATE TABLE `tb_departamento` (
  `idTB_Departamento` int NOT NULL,
  `Departamento_Nome` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `tb_departamento`
--

INSERT INTO `tb_departamento` (`idTB_Departamento`, `Departamento_Nome`) VALUES
(1, 'Vendas'),
(2, 'Recursos Humanos'),
(3, 'TI'),
(4, 'Marketing'),
(5, 'Contabilidade');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_gestor`
--

CREATE TABLE `tb_gestor` (
  `idTB_Gestor` int NOT NULL,
  `TB_Departamento_idTB_Departamento` int NOT NULL,
  `Empresa_Contratante_idEmpresa_Contratante` int NOT NULL,
  `Gestor_Nome` varchar(30) DEFAULT NULL,
  `Gestor_CPF` varchar(14) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Gestor_Email` varchar(35) DEFAULT NULL,
  `Gestor_Nascimento` date DEFAULT NULL,
  `Gestor_Telefone` varchar(15) DEFAULT NULL,
  `Gestor_Adimissao` date DEFAULT NULL,
  `Gestor_Senha` varchar(25) DEFAULT NULL,
  `Gestor_Status` tinyint(1) DEFAULT NULL,
  `Gestor_Foto` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `tb_gestor`
--

INSERT INTO `tb_gestor` (`idTB_Gestor`, `TB_Departamento_idTB_Departamento`, `Empresa_Contratante_idEmpresa_Contratante`, `Gestor_Nome`, `Gestor_CPF`, `Gestor_Email`, `Gestor_Nascimento`, `Gestor_Telefone`, `Gestor_Adimissao`, `Gestor_Senha`, `Gestor_Status`, `Gestor_Foto`) VALUES
(1, 3, 1, 'Felipe Valeriano', '516.312.956-94', 'felipe@fatec.com', '2003-10-09', '11962849652', '2023-09-07', '123', 1, NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_questionario`
--

CREATE TABLE `tb_questionario` (
  `idTB_Questionario` int NOT NULL,
  `TB_Gestor_idTB_Gestor` int NOT NULL,
  `Questionario_Descricao` varchar(255) DEFAULT NULL,
  `Questionario_Inicio` datetime DEFAULT NULL,
  `Questionario_Fim` datetime DEFAULT NULL,
  `Questionario_Qta_Perguntas` int DEFAULT NULL,
  `Questionario_Status` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `tb_questionario`
--

INSERT INTO `tb_questionario` (`idTB_Questionario`, `TB_Gestor_idTB_Gestor`, `Questionario_Descricao`, `Questionario_Inicio`, `Questionario_Fim`, `Questionario_Qta_Perguntas`, `Questionario_Status`) VALUES
(1, 1, 'aaaa', '2023-10-11 00:00:00', '2023-10-18 00:00:00', 9, 1),
(2, 1, 'dasdsa', '2023-10-11 00:00:00', '2023-10-04 00:00:00', 9, 1),
(3, 1, 'dasdsa', '2023-10-11 00:00:00', '2023-10-04 00:00:00', 9, 1),
(4, 1, 'dasdsa', '2023-10-11 00:00:00', '2023-10-04 00:00:00', 9, 1),
(5, 1, 'dasdsa', '2023-10-11 00:00:00', '2023-10-04 00:00:00', 9, 1),
(6, 1, 'dasdsa', '2023-10-11 00:00:00', '2023-10-04 00:00:00', 9, 1),
(7, 1, 'dasdsa', '2023-10-11 00:00:00', '2023-10-04 00:00:00', 9, 1),
(8, 1, 'TESTETETSTEE', '2023-10-11 00:00:00', '2023-11-01 00:00:00', 15, 1),
(9, 1, 'TESTETETSTEE', '2023-10-11 00:00:00', '2023-11-01 00:00:00', 15, 1),
(10, 1, 'Felipe Valeriano ', '2023-10-09 00:00:00', '2023-10-12 00:00:00', 5, 1),
(11, 1, 'Felipe Valeriano ', '2023-10-09 00:00:00', '2023-10-12 00:00:00', 5, 1),
(12, 1, 'FELIPEREIS', '2023-10-04 00:00:00', '2023-10-09 00:00:00', 7, 1),
(13, 1, 'aaaaa', '2023-10-09 00:00:00', '2023-10-09 00:00:00', 10, 1),
(14, 1, 'aaaaa', '2023-10-09 00:00:00', '2023-10-09 00:00:00', 10, 1),
(15, 1, 'aaaaa', '2023-10-09 00:00:00', '2023-10-09 00:00:00', 10, 1),
(16, 1, 'ama', '2023-10-06 00:00:00', '2023-10-06 00:00:00', 5, 1),
(17, 1, 'dasdas', '2023-10-14 00:00:00', '2023-10-14 00:00:00', 15, 1),
(18, 1, 'aaaaa', '2023-09-06 00:00:00', '2023-10-13 00:00:00', 5, 1),
(19, 1, 'dsadasdas', '2023-05-23 00:00:00', '2023-06-08 00:00:00', 15, 1),
(20, 1, 'dadasdsa', '2023-11-08 00:00:00', '2023-11-16 00:00:00', 8, 1),
(21, 1, 'dsadsa', '2023-10-07 00:00:00', '2023-10-01 00:00:00', 5, 1),
(22, 1, 'bolt', '2023-10-03 00:00:00', '2023-10-14 00:00:00', 10, 1),
(23, 1, 'Vai dar certo ', '2023-10-09 00:00:00', '2023-11-08 00:00:00', 9, 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_questionario_has_tb_categoria`
--

CREATE TABLE `tb_questionario_has_tb_categoria` (
  `TB_Questionario_idTB_Questionario` int NOT NULL,
  `TB_Categoria_idTB_Categoria` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `tb_questionario_has_tb_categoria`
--

INSERT INTO `tb_questionario_has_tb_categoria` (`TB_Questionario_idTB_Questionario`, `TB_Categoria_idTB_Categoria`) VALUES
(23, 3),
(23, 4);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_questoes`
--

CREATE TABLE `tb_questoes` (
  `idTB_Questoes` int NOT NULL,
  `TB_Gestor_idTB_Gestor` int NOT NULL,
  `TB_Tipo_Questao_idTB_Tipo_Questao` int NOT NULL,
  `TB_Categoria_idTB_Categoria` int NOT NULL,
  `Questoes_Pergunta` varchar(255) DEFAULT NULL,
  `Questoes_A` varchar(255) DEFAULT NULL,
  `Questoes_B` varchar(255) DEFAULT NULL,
  `Questoes_C` varchar(255) DEFAULT NULL,
  `Questoes_D` varchar(255) DEFAULT NULL,
  `Questao_Correta` varchar(255) DEFAULT NULL,
  `Questao_Data` date DEFAULT NULL,
  `Questao_Status` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `tb_questoes`
--

INSERT INTO `tb_questoes` (`idTB_Questoes`, `TB_Gestor_idTB_Gestor`, `TB_Tipo_Questao_idTB_Tipo_Questao`, `TB_Categoria_idTB_Categoria`, `Questoes_Pergunta`, `Questoes_A`, `Questoes_B`, `Questoes_C`, `Questoes_D`, `Questao_Correta`, `Questao_Data`, `Questao_Status`) VALUES
(1, 1, 1, 4, '(UFT-TO) A nota final para uma disciplina de uma instituição de ensino superior é a média ponderada das notas A, B e C, cujos pesos são 1, 2 e 3, respectivamente. Paulo obteve A = 3,0 e B = 6,0. Quanto ele deve obter em C para que sua nota final seja 6,0?', '7', '8', '9', 'A', 'A', '2023-10-11', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_tipo_questao`
--

CREATE TABLE `tb_tipo_questao` (
  `idTB_Tipo_Questao` int NOT NULL,
  `Tipo_Nome` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `tb_tipo_questao`
--

INSERT INTO `tb_tipo_questao` (`idTB_Tipo_Questao`, `Tipo_Nome`) VALUES
(1, 'Tecnica'),
(2, 'Comportamental');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `empresa_contratante`
--
ALTER TABLE `empresa_contratante`
  ADD PRIMARY KEY (`idEmpresa_Contratante`);

--
-- Índices de tabela `tb_categoria`
--
ALTER TABLE `tb_categoria`
  ADD PRIMARY KEY (`idTB_Categoria`);

--
-- Índices de tabela `tb_colaborador`
--
ALTER TABLE `tb_colaborador`
  ADD PRIMARY KEY (`idTB_Colaborador`),
  ADD KEY `TB_Colaborador_FKIndex1` (`TB_Gestor_idTB_Gestor`),
  ADD KEY `IFK_Rel_22` (`TB_Gestor_idTB_Gestor`);

--
-- Índices de tabela `tb_colaborador_associa_tb_questionario`
--
ALTER TABLE `tb_colaborador_associa_tb_questionario`
  ADD PRIMARY KEY (`TB_Colaborador_idTB_Colaborador`,`TB_Questionario_idTB_Questionario`),
  ADD KEY `TB_Colaborador_has_TB_Questionario_FKIndex1` (`TB_Colaborador_idTB_Colaborador`),
  ADD KEY `TB_Colaborador_has_TB_Questionario_FKIndex2` (`TB_Questionario_idTB_Questionario`),
  ADD KEY `IFK_Rel_33` (`TB_Colaborador_idTB_Colaborador`),
  ADD KEY `IFK_Rel_34` (`TB_Questionario_idTB_Questionario`);

--
-- Índices de tabela `tb_departamento`
--
ALTER TABLE `tb_departamento`
  ADD PRIMARY KEY (`idTB_Departamento`);

--
-- Índices de tabela `tb_gestor`
--
ALTER TABLE `tb_gestor`
  ADD PRIMARY KEY (`idTB_Gestor`),
  ADD KEY `TB_Gestor_FKIndex1` (`Empresa_Contratante_idEmpresa_Contratante`),
  ADD KEY `TB_Gestor_FKIndex2` (`TB_Departamento_idTB_Departamento`),
  ADD KEY `IFK_Rel_20` (`Empresa_Contratante_idEmpresa_Contratante`),
  ADD KEY `IFK_Rel_21` (`TB_Departamento_idTB_Departamento`);

--
-- Índices de tabela `tb_questionario`
--
ALTER TABLE `tb_questionario`
  ADD PRIMARY KEY (`idTB_Questionario`),
  ADD KEY `TB_Questionario_FKIndex1` (`TB_Gestor_idTB_Gestor`),
  ADD KEY `IFK_Rel_09` (`TB_Gestor_idTB_Gestor`);

--
-- Índices de tabela `tb_questionario_has_tb_categoria`
--
ALTER TABLE `tb_questionario_has_tb_categoria`
  ADD PRIMARY KEY (`TB_Questionario_idTB_Questionario`,`TB_Categoria_idTB_Categoria`),
  ADD KEY `TB_Questionario_has_TB_Categoria_FKIndex1` (`TB_Questionario_idTB_Questionario`),
  ADD KEY `TB_Questionario_has_TB_Categoria_FKIndex2` (`TB_Categoria_idTB_Categoria`),
  ADD KEY `IFK_Rel_10` (`TB_Questionario_idTB_Questionario`),
  ADD KEY `IFK_Rel_11` (`TB_Categoria_idTB_Categoria`);

--
-- Índices de tabela `tb_questoes`
--
ALTER TABLE `tb_questoes`
  ADD PRIMARY KEY (`idTB_Questoes`),
  ADD KEY `TB_Questoes_FKIndex1` (`TB_Categoria_idTB_Categoria`),
  ADD KEY `TB_Questoes_FKIndex2` (`TB_Tipo_Questao_idTB_Tipo_Questao`),
  ADD KEY `TB_Questoes_FKIndex3` (`TB_Gestor_idTB_Gestor`),
  ADD KEY `IFK_Rel_23` (`TB_Categoria_idTB_Categoria`),
  ADD KEY `IFK_Rel_24` (`TB_Tipo_Questao_idTB_Tipo_Questao`),
  ADD KEY `IFK_Rel_25` (`TB_Gestor_idTB_Gestor`);

--
-- Índices de tabela `tb_tipo_questao`
--
ALTER TABLE `tb_tipo_questao`
  ADD PRIMARY KEY (`idTB_Tipo_Questao`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `empresa_contratante`
--
ALTER TABLE `empresa_contratante`
  MODIFY `idEmpresa_Contratante` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `tb_categoria`
--
ALTER TABLE `tb_categoria`
  MODIFY `idTB_Categoria` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de tabela `tb_colaborador`
--
ALTER TABLE `tb_colaborador`
  MODIFY `idTB_Colaborador` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `tb_departamento`
--
ALTER TABLE `tb_departamento`
  MODIFY `idTB_Departamento` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `tb_gestor`
--
ALTER TABLE `tb_gestor`
  MODIFY `idTB_Gestor` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `tb_questionario`
--
ALTER TABLE `tb_questionario`
  MODIFY `idTB_Questionario` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de tabela `tb_questoes`
--
ALTER TABLE `tb_questoes`
  MODIFY `idTB_Questoes` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `tb_tipo_questao`
--
ALTER TABLE `tb_tipo_questao`
  MODIFY `idTB_Tipo_Questao` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `tb_colaborador`
--
ALTER TABLE `tb_colaborador`
  ADD CONSTRAINT `tb_colaborador_ibfk_1` FOREIGN KEY (`TB_Gestor_idTB_Gestor`) REFERENCES `tb_gestor` (`idTB_Gestor`);

--
-- Restrições para tabelas `tb_colaborador_associa_tb_questionario`
--
ALTER TABLE `tb_colaborador_associa_tb_questionario`
  ADD CONSTRAINT `tb_colaborador_associa_tb_questionario_ibfk_1` FOREIGN KEY (`TB_Colaborador_idTB_Colaborador`) REFERENCES `tb_colaborador` (`idTB_Colaborador`),
  ADD CONSTRAINT `tb_colaborador_associa_tb_questionario_ibfk_2` FOREIGN KEY (`TB_Questionario_idTB_Questionario`) REFERENCES `tb_questionario` (`idTB_Questionario`);

--
-- Restrições para tabelas `tb_gestor`
--
ALTER TABLE `tb_gestor`
  ADD CONSTRAINT `tb_gestor_ibfk_1` FOREIGN KEY (`Empresa_Contratante_idEmpresa_Contratante`) REFERENCES `empresa_contratante` (`idEmpresa_Contratante`),
  ADD CONSTRAINT `tb_gestor_ibfk_2` FOREIGN KEY (`TB_Departamento_idTB_Departamento`) REFERENCES `tb_departamento` (`idTB_Departamento`);

--
-- Restrições para tabelas `tb_questionario`
--
ALTER TABLE `tb_questionario`
  ADD CONSTRAINT `tb_questionario_ibfk_1` FOREIGN KEY (`TB_Gestor_idTB_Gestor`) REFERENCES `tb_gestor` (`idTB_Gestor`);

--
-- Restrições para tabelas `tb_questionario_has_tb_categoria`
--
ALTER TABLE `tb_questionario_has_tb_categoria`
  ADD CONSTRAINT `tb_questionario_has_tb_categoria_ibfk_1` FOREIGN KEY (`TB_Questionario_idTB_Questionario`) REFERENCES `tb_questionario` (`idTB_Questionario`),
  ADD CONSTRAINT `tb_questionario_has_tb_categoria_ibfk_2` FOREIGN KEY (`TB_Categoria_idTB_Categoria`) REFERENCES `tb_categoria` (`idTB_Categoria`);

--
-- Restrições para tabelas `tb_questoes`
--
ALTER TABLE `tb_questoes`
  ADD CONSTRAINT `tb_questoes_ibfk_1` FOREIGN KEY (`TB_Categoria_idTB_Categoria`) REFERENCES `tb_categoria` (`idTB_Categoria`),
  ADD CONSTRAINT `tb_questoes_ibfk_2` FOREIGN KEY (`TB_Tipo_Questao_idTB_Tipo_Questao`) REFERENCES `tb_tipo_questao` (`idTB_Tipo_Questao`),
  ADD CONSTRAINT `tb_questoes_ibfk_3` FOREIGN KEY (`TB_Gestor_idTB_Gestor`) REFERENCES `tb_gestor` (`idTB_Gestor`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
