-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 21/09/2023 às 01:01
-- Versão do servidor: 8.0.32
-- Versão do PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `autorating`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_categoria`
--

CREATE TABLE `tb_categoria` (
  `idTB_Categoria` int NOT NULL,
  `Categoria_Nome` varchar(35) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_colaborador`
--

CREATE TABLE `tb_colaborador` (
  `idTB_Colaborador` int NOT NULL,
  `TB_Gestor_idTB_Gestor` int NOT NULL,
  `Colaborador_Nome` varchar(30) DEFAULT NULL,
  `Colaborador_CPF` varchar(14) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Colaborador_Email` varchar(35) DEFAULT NULL,
  `Colaborador_Nascimento` date DEFAULT NULL,
  `Colaborador_Telefone` varchar(15) DEFAULT NULL,
  `Colaborador_Adimissao` date DEFAULT NULL,
  `Colaborador_Senha` varchar(25) DEFAULT NULL,
  `Colaborador_Status` tinyint(1) DEFAULT NULL,
  `Colaborador_Foto` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Colaborador_Funcao` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `tb_colaborador`
--

INSERT INTO `tb_colaborador` (`idTB_Colaborador`, `TB_Gestor_idTB_Gestor`, `Colaborador_Nome`, `Colaborador_CPF`, `Colaborador_Email`, `Colaborador_Nascimento`, `Colaborador_Telefone`, `Colaborador_Adimissao`, `Colaborador_Senha`, `Colaborador_Status`, `Colaborador_Foto`, `Colaborador_Funcao`) VALUES
(19, 1, 'Felipe Valeriano dos Reis', '605.567.210-39', 'felipevalerianodosreis@gmail.com', '2002-04-05', '11962849591', '2023-09-04', 'Matheus', 0, '../../../COLABORADOR/UPLOADS_IMAGENS/605.567.210-39.png', 'Back-End Junior'),
(20, 1, 'Julia ', '710.827.160-57', 'JuliaSantos@FatecZs.com', '1998-08-05', '11962869596', '2023-09-05', 'Julia', 0, '../../../COLABORADOR/UPLOADS_IMAGENS/710.827.160-57.png', 'Front-End Senior'),
(21, 1, 'Rebecca Santos Reis', '447.696.630-64', 'Rebeca_Santos@gmail.com', '2005-02-05', '11962549625', '2023-09-19', '123', 0, '../../../COLABORADOR/UPLOADS_IMAGENS/447.696.630-64.png', 'Analista Jr'),
(22, 2, 'Vanessa Soares Marques', '384.511.460-66', 'Vanessa_Marques@gmail.com', '1980-02-18', '11968959632', '2023-09-18', 'Vanessa', 1, 'uploads/woman.jpg', 'Business Partner'),
(23, 1, 'Cintia Reis', '682.252.140-21', 'Cintia@gmail.com', '1988-11-08', '11962849591', '2023-09-19', 'aaaaaa', 0, '../../../COLABORADOR/UPLOADS_IMAGENS/682.252.140-21.png', 'Back-end'),
(24, 1, 'Felipe Valeriano dos Reis', '1656780120', 'felipevalerianodosreis@gmail.com', '2023-09-20', '11962849591', '2023-09-20', 'dsad', 1, '../../../COLABORADOR/UPLOADS_IMAGENS/1656780120.png', 'dsadas'),
(25, 1, 'Felipe Valeriano dos Reis', '545454545', 'felipevalerianodosreis@gmail.com', '2023-09-19', '11962849591', '2023-09-19', 'aaa', 0, '../../UPLOADS_IMAGENS.png', 'dsadsa'),
(26, 1, 'Felipe Valeriano dos Reis', '4545454', 'felipevalerianodosreis@gmail.com', '2023-09-21', '11962849591', '2023-09-28', 'aaa', 0, '../../UPLOADS_IMAGENS4545454.png', 'dsadsa'),
(27, 1, 'dsadsa', '5645656', 'felipevalerianodosreis@gmail.com', '2023-09-20', '11962849591', '2023-09-19', 'aaa', 0, '../../../COLABORADOR/UPLOADS_IMAGENS/5645656.png', 'dsadas'),
(28, 1, 'Felipe Valeriano dos Reis', '5645', 'felipevalerianodosreis@gmail.com', '2023-09-19', '11962849591', '2023-09-20', 'aa', 1, '../../../COLABORADOR/UPLOADS_IMAGENS/5645.png', 'dsadsa'),
(29, 1, 'Felipe Valeriano dos Reis', '521.569.963-96', 'felipevalerianodosreis@gmail.com', '2023-09-19', '11962849591', '2023-09-21', 'AAA', 0, '../../../COLABORADOR/UPLOADS_IMAGENS/521.569.963-96.png', 'AAA'),
(30, 1, 'dasdasda', '454545456', 'felipevalerianodosreis@gmail.com', '2023-09-20', '11962849591', '2023-09-19', 'aaa', 1, '../../../COLABORADOR/UPLOADS_IMAGENS/454545456.png', 'dsadas'),
(31, 1, 'Felipe Valeriano dos Reis', '541.296.859-83', 'felipevalerianodosreis@gmail.com', '2003-10-09', '11962849591', '2023-09-22', 'aaa', 1, '../../../COLABORADOR/UPLOADS_IMAGENS/541.296.859-83.png', 'hgyg'),
(32, 1, 'Felipe Valeriano dos Reis', '111.111.111-11', 'felipevalerianodosreis@gmail.com', '2023-09-29', '11962849591', '2023-09-06', 'aaa', 1, '../../../COLABORADOR/UPLOADS_IMAGENS/111.111.111-11.png', 'aaa'),
(33, 1, 'Felipe Valeriano dos Reis', '179.901.430-46', 'felipevalerianodosreis@gmail.com', '2023-09-20', '11962849591', '2023-09-21', 'aaa', 1, '../../../COLABORADOR/UPLOADS_IMAGENS/179.901.430-46.png', 'dasds'),
(34, 1, 'Felipe Valeriano dos Reis', '911.334.940-64', 'felipevalerianodosreis@gmail.com', '2023-09-20', '11962849591', '2023-09-21', '123', 0, '../../../COLABORADOR/UPLOADS_IMAGENS/911.334.940-64.png', 'aaa'),
(35, 1, 'Felipe Valeriano dos Reis', '186.027.130-88', 'felipevalerianodosreis@gmail.com', '2023-09-21', '11962849591', '2023-09-20', 'aaa', 0, '../../../COLABORADOR/UPLOADS_IMAGENS/186.027.130-88.png', 'aaa'),
(36, 1, 'Felipe Valeriano dos Reis', '037.688.380-48', 'felipevalerianodosreis@gmail.com', '2023-09-07', '11962849591', '2023-09-29', 'aaa', 0, '../../../COLABORADOR/UPLOADS_IMAGENS/037.688.380-48.jpg', 'aaa');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_departamento`
--

CREATE TABLE `tb_departamento` (
  `idTB_Departamento` int NOT NULL,
  `Departamento_Nome` varchar(25) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `tb_departamento`
--

INSERT INTO `tb_departamento` (`idTB_Departamento`, `Departamento_Nome`) VALUES
(1, 'T.I'),
(2, 'RH');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_gestor`
--

CREATE TABLE `tb_gestor` (
  `idTB_Gestor` int NOT NULL,
  `TB_Departamento_idTB_Departamento` int NOT NULL,
  `Gestor_Nome` varchar(30) DEFAULT NULL,
  `Gestor_CPF` varchar(14) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `Gestor_Email` varchar(35) DEFAULT NULL,
  `Gestor_Nascimento` date DEFAULT NULL,
  `Gestor_Telefone` varchar(15) DEFAULT NULL,
  `Gestor_Adimissao` date DEFAULT NULL,
  `Gestor_Senha` varchar(25) DEFAULT NULL,
  `Gestor_Status` tinyint(1) DEFAULT NULL,
  `Gestor_Foto` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Despejando dados para a tabela `tb_gestor`
--

INSERT INTO `tb_gestor` (`idTB_Gestor`, `TB_Departamento_idTB_Departamento`, `Gestor_Nome`, `Gestor_CPF`, `Gestor_Email`, `Gestor_Nascimento`, `Gestor_Telefone`, `Gestor_Adimissao`, `Gestor_Senha`, `Gestor_Status`, `Gestor_Foto`) VALUES
(1, 1, 'Felipe Valeriano ', '516.312.956-94', 'felipevalerianodosreis@gmail.com', '2003-10-09', '11962849591', '2023-09-12', '123', 1, 'gestor1.png'),
(2, 2, 'Adriana Santos', '521.569.963-96', 'Adrina@gmail.com', '1990-02-06', '11962849652', '2023-09-07', 'aaa', 1, 'adriana.png');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_questionario`
--

CREATE TABLE `tb_questionario` (
  `idTB_Questionario` int NOT NULL,
  `TB_Gestor_idTB_Gestor` int NOT NULL,
  `TB_Colaborador_idTB_Colaborador` int NOT NULL,
  `Questionario_Descricao` varchar(255) DEFAULT NULL,
  `Questionario_Inicio` datetime DEFAULT NULL,
  `Questionario_Fim` datetime DEFAULT NULL,
  `Questionario_Qta_Perguntas` int DEFAULT NULL,
  `Questionario_Status` tinyint(1) DEFAULT NULL,
  `Questionario_Resultado` int DEFAULT NULL,
  `Questionario_Duracao` time DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_questionario_has_tb_questoes`
--

CREATE TABLE `tb_questionario_has_tb_questoes` (
  `TB_Questionario_idTB_Questionario` int NOT NULL,
  `TB_Questoes_idTB_Questoes` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_questoes`
--

CREATE TABLE `tb_questoes` (
  `idTB_Questoes` int NOT NULL,
  `TB_Tipo_Questao_idTB_Tipo_Questao` int NOT NULL,
  `TB_Categoria_idTB_Categoria` int NOT NULL,
  `Questoes_Pergunta` varchar(255) DEFAULT NULL,
  `Questoes_A` varchar(255) DEFAULT NULL,
  `Questoes_B` varchar(255) DEFAULT NULL,
  `Questoes_C` varchar(255) DEFAULT NULL,
  `Questoes_D` varchar(255) DEFAULT NULL,
  `Questao_Correta` varchar(255) DEFAULT NULL,
  `Questao_Data` date DEFAULT NULL,
  `Questao_Status` tinyint(1) DEFAULT NULL,
  `Questao_Dificuldade` int DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `tb_tipo_questao`
--

CREATE TABLE `tb_tipo_questao` (
  `idTB_Tipo_Questao` int NOT NULL,
  `Tipo_Nome` varchar(20) DEFAULT NULL,
  `Tipo_Descricao` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `tb_categoria`
--
ALTER TABLE `tb_categoria`
  ADD PRIMARY KEY (`idTB_Categoria`);

--
-- Índices de tabela `tb_colaborador`
--
ALTER TABLE `tb_colaborador`
  ADD PRIMARY KEY (`idTB_Colaborador`),
  ADD KEY `TB_Colaborador_FKIndex1` (`TB_Gestor_idTB_Gestor`),
  ADD KEY `IFK_Rel_01` (`TB_Gestor_idTB_Gestor`);

--
-- Índices de tabela `tb_departamento`
--
ALTER TABLE `tb_departamento`
  ADD PRIMARY KEY (`idTB_Departamento`);

--
-- Índices de tabela `tb_gestor`
--
ALTER TABLE `tb_gestor`
  ADD PRIMARY KEY (`idTB_Gestor`),
  ADD KEY `TB_Gestor_FKIndex1` (`TB_Departamento_idTB_Departamento`),
  ADD KEY `IFK_Rel_03` (`TB_Departamento_idTB_Departamento`);

--
-- Índices de tabela `tb_questionario`
--
ALTER TABLE `tb_questionario`
  ADD PRIMARY KEY (`idTB_Questionario`),
  ADD KEY `TB_Questionario_FKIndex1` (`TB_Colaborador_idTB_Colaborador`),
  ADD KEY `TB_Questionario_FKIndex2` (`TB_Gestor_idTB_Gestor`),
  ADD KEY `IFK_Rel_06` (`TB_Colaborador_idTB_Colaborador`),
  ADD KEY `IFK_Rel_09` (`TB_Gestor_idTB_Gestor`);

--
-- Índices de tabela `tb_questionario_has_tb_questoes`
--
ALTER TABLE `tb_questionario_has_tb_questoes`
  ADD PRIMARY KEY (`TB_Questionario_idTB_Questionario`,`TB_Questoes_idTB_Questoes`),
  ADD KEY `TB_Questionario_has_TB_Questoes_FKIndex1` (`TB_Questionario_idTB_Questionario`),
  ADD KEY `TB_Questionario_has_TB_Questoes_FKIndex2` (`TB_Questoes_idTB_Questoes`),
  ADD KEY `IFK_Rel_07` (`TB_Questionario_idTB_Questionario`),
  ADD KEY `IFK_Rel_08` (`TB_Questoes_idTB_Questoes`);

--
-- Índices de tabela `tb_questoes`
--
ALTER TABLE `tb_questoes`
  ADD PRIMARY KEY (`idTB_Questoes`),
  ADD KEY `TB_Questoes_FKIndex1` (`TB_Categoria_idTB_Categoria`),
  ADD KEY `TB_Questoes_FKIndex2` (`TB_Tipo_Questao_idTB_Tipo_Questao`),
  ADD KEY `IFK_Rel_04` (`TB_Categoria_idTB_Categoria`),
  ADD KEY `IFK_Rel_05` (`TB_Tipo_Questao_idTB_Tipo_Questao`);

--
-- Índices de tabela `tb_tipo_questao`
--
ALTER TABLE `tb_tipo_questao`
  ADD PRIMARY KEY (`idTB_Tipo_Questao`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `tb_categoria`
--
ALTER TABLE `tb_categoria`
  MODIFY `idTB_Categoria` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `tb_colaborador`
--
ALTER TABLE `tb_colaborador`
  MODIFY `idTB_Colaborador` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT de tabela `tb_departamento`
--
ALTER TABLE `tb_departamento`
  MODIFY `idTB_Departamento` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `tb_gestor`
--
ALTER TABLE `tb_gestor`
  MODIFY `idTB_Gestor` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `tb_questionario`
--
ALTER TABLE `tb_questionario`
  MODIFY `idTB_Questionario` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `tb_questoes`
--
ALTER TABLE `tb_questoes`
  MODIFY `idTB_Questoes` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `tb_tipo_questao`
--
ALTER TABLE `tb_tipo_questao`
  MODIFY `idTB_Tipo_Questao` int NOT NULL AUTO_INCREMENT;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `tb_colaborador`
--
ALTER TABLE `tb_colaborador`
  ADD CONSTRAINT `tb_colaborador_ibfk_1` FOREIGN KEY (`TB_Gestor_idTB_Gestor`) REFERENCES `tb_gestor` (`idTB_Gestor`);

--
-- Restrições para tabelas `tb_gestor`
--
ALTER TABLE `tb_gestor`
  ADD CONSTRAINT `tb_gestor_ibfk_1` FOREIGN KEY (`TB_Departamento_idTB_Departamento`) REFERENCES `tb_departamento` (`idTB_Departamento`);

--
-- Restrições para tabelas `tb_questionario`
--
ALTER TABLE `tb_questionario`
  ADD CONSTRAINT `tb_questionario_ibfk_1` FOREIGN KEY (`TB_Colaborador_idTB_Colaborador`) REFERENCES `tb_colaborador` (`idTB_Colaborador`),
  ADD CONSTRAINT `tb_questionario_ibfk_2` FOREIGN KEY (`TB_Gestor_idTB_Gestor`) REFERENCES `tb_gestor` (`idTB_Gestor`);

--
-- Restrições para tabelas `tb_questionario_has_tb_questoes`
--
ALTER TABLE `tb_questionario_has_tb_questoes`
  ADD CONSTRAINT `tb_questionario_has_tb_questoes_ibfk_1` FOREIGN KEY (`TB_Questionario_idTB_Questionario`) REFERENCES `tb_questionario` (`idTB_Questionario`),
  ADD CONSTRAINT `tb_questionario_has_tb_questoes_ibfk_2` FOREIGN KEY (`TB_Questoes_idTB_Questoes`) REFERENCES `tb_questoes` (`idTB_Questoes`);

--
-- Restrições para tabelas `tb_questoes`
--
ALTER TABLE `tb_questoes`
  ADD CONSTRAINT `tb_questoes_ibfk_1` FOREIGN KEY (`TB_Categoria_idTB_Categoria`) REFERENCES `tb_categoria` (`idTB_Categoria`),
  ADD CONSTRAINT `tb_questoes_ibfk_2` FOREIGN KEY (`TB_Tipo_Questao_idTB_Tipo_Questao`) REFERENCES `tb_tipo_questao` (`idTB_Tipo_Questao`);
 ADD CONSTRAINT `tb_questoes_ibfk_3` FOREIGN KEY (`TB_Gestor_idTB_Gestor`) REFERENCES `tb_gestor` (`idTB_Gestor`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
