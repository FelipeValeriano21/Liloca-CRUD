
<?php
include '../../../../ConexaoPHP/conexao.php';
session_start();

$cpf = $_SESSION['cpf'];

// Consulta para obter dados do colaborador
$procedure = "SELECT * FROM tb_colaborador WHERE Colaborador_CPF = '$cpf'";
$sql = mysqli_query($conn, $procedure) or die(mysqli_error($conn));

while ($dados = mysqli_fetch_assoc($sql)) {

    $foto = $dados['Colaborador_Foto'];
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Departamento - AUTORATING</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css">    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">
    <link rel="stylesheet" href="../../assets/bootstrap/css/side.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/fonts/fontawesome-all.min.css">
    <link rel="stylesheet" href="assets/css/styles.min.css">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap" rel="stylesheet"/>

<link href="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.2/mdb.min.css" rel="stylesheet"/>
     <link rel="shortcut icon" type="imagex/png" href="../Login/img/AUTORATING.png">
</head>
<body id="body-pd">
    <header class="header" id="header">
        <div style="color: white;" class="header_toggle "> <i class='bx bx-expand-horizontal' id="header-toggle"></i> </div>
        <h3></h3>
        <a href="#" id="btn-sair" class="nav_link"> <i class='bx bx-log-out nav_icon'></i> <span class="nav_name">Sair</span> </a> 
   
    </header>
    <main>
    <div class="l-navbar" id="nav-bar"> 
        <nav class="nav">
            <div> <a href="#" class="nav_logo"> <i class='bx bx-layer nav_logo-icon' ></i> <span class="nav_logo-name">Autorating</span> </a>
               <div  class="img m-3"> 
               <img class="rounded-circle mb-3 mt-4" src="../<?php echo $foto?>" width="160" height="160" id="fotomenu">
               
              </div>
               <hr>
                <div class="nav_list mt-4">
                     <a href="../MENU/menu.php" class="nav_link"> <i class='bx bx-grid-alt nav_icon'></i> <span class="nav_name">Menu</span> </a> 
                     <a href="../COLEGAS/colegas.php" class="nav_link" > <i class='bx bx-group nav_icon'></i> <span class="nav_name">Meu departamento</span> </a> 
                     <a href="realizadas.php" class="nav_link active"> <i class='bx bx-check nav_icon '></i> <span class="nav_name">Realizadas</span> </a> 
                     <a href="../DASHBOARD/Dashboard.php" class="nav_link "> <i class='bx bx-bar-chart-alt-2 nav_icon'></i> <span class="nav_name">Dashboard</span> </a> 
                     <a href="../PROFILE/profile.php" class="nav_link"> <i class='bx bx-user nav_icon'></i> <span class="nav_name">Dados Pessoais</span> </a>
                    </div>
            </div> 
        </nav>
    </div>

    <main>

      <br>
      <br>
      <br>

      <blockquote class="blockquote text-center">
        <h3 class="mb-1 p-4" >Avaliação de colaborador iniciada</h3>
      </blockquote>

      <section>
        <div class="container">
            <div class="row stepper">
                <div class="col">
                    <div class="md-stepper-horizontal orange">
                        <div class="md-step active done">
                            <div class="md-step-circle green"><span>1</span></div>
                            <div class="md-step-title"><span>Questão 1</span></div>
                            <div class="md-step-bar-left"></div>
                            <div class="md-step-bar-right"></div>
                        </div>
                        <div class="md-step active editable current">
                        <div class="md-step-circle grey"><span>2</span></div>
                            <div class="md-step-title"><span><strong>Questão 2</strong></span></div>
                            <div class="md-step-bar-left"></div>
                            <div class="md-step-bar-right"></div>
                        </div>
                        <div class="md-step active editable current">
                        <div class="md-step-circle grey"><span>2</span></div>
                            <div class="md-step-title"><span><strong>Payment</strong></span></div>
                            <div class="md-step-bar-left"></div>
                            <div class="md-step-bar-right"></div>
                        </div>
                        <div class="md-step active editable current">
                        <div class="md-step-circle grey"><span>2</span></div>
                            <div class="md-step-title"><span><strong>Finalizada</strong></span></div>
                            <div class="md-step-bar-left"></div>
                            <div class="md-step-bar-right"></div>
                        </div>
                        <div class="md-step active editable current">
                            <div class="md-step-circle grey"><span>2</span></div>
                            <div class="md-step-title"><span><strong>Finalizada</strong></span></div>
                            <div class="md-step-bar-left"></div>
                            <div class="md-step-bar-right"></div>
                        </div>
                        <div class="md-step active editable current">
                            <div class="md-step-circle grey"><span>1</span></div>
                            <div class="md-step-title"><span>Questão 1</span></div>
                            <div class="md-step-bar-left"></div>
                            <div class="md-step-bar-right"></div>
                        </div>
                        <div class="md-step active editable current">
                            <div class="md-step-circle grey" style="--bs-primary: #1460cf;--bs-primary-rgb: 20,96,207;--bs-warning: #9d9d9d;--bs-warning-rgb: 157,157,157;"><span>2</span></div>
                            <div class="md-step-title"><span><strong>Questão 2</strong></span></div>
                            <div class="md-step-bar-left"></div>
                            <div class="md-step-bar-right"></div>
                        </div>
                        <div class="md-step active editable current">
                            <div class="md-step-circle grey"><span>2</span></div>
                            <div class="md-step-title"><span><strong>Payment</strong></span></div>
                            <div class="md-step-bar-left"></div>
                            <div class="md-step-bar-right"></div>
                        </div>
                        <div class="md-step active editable current">
                            <div class="md-step-circle grey"><span>2</span></div>
                            <div class="md-step-title"><span><strong>Finalizada</strong></span></div>
                            <div class="md-step-bar-left"></div>
                            <div class="md-step-bar-right"></div>
                        </div>
                        <div class="md-step active thanks">
                            <div class="md-step-circle grey"><span>2</span></div>
                            <div class="md-step-title"><span><strong>Finalizada</strong></span></div>
                            <div class="md-step-bar-left"></div>
                            <div class="md-step-bar-right"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div><i class="fa fa-star" style="display:none;"></i>
    </section>
    <br>

    <section class="container">

        <div class="mx-0 mx-sm-auto">
            <div class="card">
              <div class="card-body">
                <div class="text-center">
            
                  <p>
                    <strong>Questão 1</strong>
                  </p>
                  <p>
                    Have some ideas how to improve our product?
                    <strong>Give us your feedback.</strong>
                  </p>
                </div>
          
                <hr />
          
                <form class="px-4" action="">
                  <p class="text-center"><strong>Sua resposta:</strong></p>
          
                  <div class="form-check mb-2">
                    <input class="form-check-input" type="radio" name="exampleForm" id="radio2Example1" />
                    <label class="form-check-label" for="radio2Example1">
                      Very good
                    </label>
                  </div>
                  <div class="form-check mb-2">
                    <input class="form-check-input" type="radio" name="exampleForm" id="radio2Example2" />
                    <label class="form-check-label" for="radio2Example2">
                      Good
                    </label>
                  </div>
                  <div class="form-check mb-2">
                    <input class="form-check-input" type="radio" name="exampleForm" id="radio2Example3" />
                    <label class="form-check-label" for="radio2Example3">
                      Medicore
                    </label>
                  </div>
                  <div class="form-check mb-2">
                    <input class="form-check-input" type="radio" name="exampleForm" id="radio2Example4" />
                    <label class="form-check-label" for="radio2Example4">
                      Bad
                    </label>
                  </div>
         
                </form>
              </div>
              <div class="card-footer text-end">
              <button type="button" class="btn btn-primary" style="background-color: rgb(0, 87, 127);">Voltar</button>
                <button type="button" class="btn btn-primary"  style="background-color: rgb(0, 87, 127);">Proxima</button>
           
              </div>
            </div>
          </div>

    </section>

     
      

    </main>

    <footer class="sticky-footer">
                        <div class="container my-auto">
                            <div class="text-center my-auto copyright"><span>©TECHNOTRIBEMLV2023</span></div>
                        </div>
                    </footer>

  <!--

 <footer>   
      <div class="text-center p-4" style=" background-color: rgb(8, 87, 156); color: white;">
      © 2023 Copyright: TECHNOTRIBE MLV
      </div>
  </footer>


  -->
  
 
</body>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/js/script.min.js"></script>
<script src="assets/js/chart.min.min.js"></script>       
<script src="../../assets/js/main.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.bundle.min.js"></script>
</html>